Environment: Python, Django, Django Rest Framework,  Heroku
1. Install all dependencies in "Requirements.txt" file
2. Start server using command "python manage.py runserver"
3. Ensure that memcached server is running.
4. Start Postman Tool and run the urls as mentioned in "urls.py" file with localhost
5. Verify the result
6. Run "Python manage.py test " for testing coverage with multiple parameters
7. Run url "https://hatchwaysherokuapp.herokuapp.com/ + url routes" in urls.py file
