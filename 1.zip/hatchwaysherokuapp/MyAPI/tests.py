from django.test import Client
from django.urls import reverse
from django.test import TestCase

from rest_framework import status

class test_Step1(TestCase):
    def test_step1(self):
        print("Step 1 testing starts")
        client  =Client()
        response = client.get(reverse('ping'))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        print("Pass")

class test_Step2(TestCase):
    def test_step2(self):
        print("Step 2 testing starts")
        client = Client()
        different_params = ("", "history", "science,tech", "zz", "=****(")
        status_codes = (status.HTTP_400_BAD_REQUEST, status.HTTP_200_OK, status.HTTP_200_OK , status.HTTP_200_OK, status.HTTP_200_OK)

        url =  'posts'
        for i, j  in zip(different_params,status_codes):
            response = client.get(reverse(url), {'tag':i})
            self.assertEqual(response.status_code ,j)
            print("Pass")


class test_Step3(TestCase):
    url = 'posts with params'
    client = Client()

    def test_step3_single(self):
        print("Step 3 testing starts")
        different_params = ("","sci", "science", )
        status_codes = (status.HTTP_400_BAD_REQUEST, status.HTTP_200_OK, status.HTTP_200_OK)
        for i, j in zip(different_params, status_codes):
            response = self.client.get(reverse(self.url), {'tag': i})
            self.assertEqual(response.status_code, j)
            print("Pass")

    def test_step3_valid_sortby(self):
        response = self.client.get(reverse(self.url), {'tag': 'science', 'sortBy':'likes'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        print("Pass")

    def test_step3_valid_sortby_desc(self):
        response = self.client.get(reverse(self.url), {'tag': 'history', 'sortBy': 'id', 'direction':'desc'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        print("Pass")

    def test_step3_invalid_sortby_(self):
        response = self.client.get(reverse(self.url), {'tag': 'tech', 'sortBy': 'jkh(**k))', 'direction': 'asc'})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        print("Pass")

    def test_step3_invalid_direction(self):
        response = self.client.get(reverse(self.url), {'tag': 'culture', 'sortBy': 'popularity', 'direction': 'desccc'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        print("Pass")

class test_Step4(TestCase):
    url = 'authors_posts'
    client = Client()

    def test_step4_positive(self):
        print("Step 4 testing starts")
        response = self.client.get(reverse(self.url))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        print("Pass")

    def test_step4_negative(self):
        response = self.client.get(reverse(self.url), {"xyz":""})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        print("Pass")

