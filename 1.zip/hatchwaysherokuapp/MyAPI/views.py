## Program to fetch data from Hatchways API

#Rest framework imports
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

#Django imports
from django.http import HttpResponse, JsonResponse
from django.core.cache import cache

#Other imports
from operator import itemgetter
import json
import requests
import itertools


def get_cached_data(link, key):
    cached = cache.get(key)
    if not cached:
        data = requests.get(link).json()
        if data:
            cache.set(key, data, 500)
            cached = cache.get(key)
            return cached
        else:
            return ("Error in fetching data")
    return cached

class Step1View(APIView):

    def get(self, request, format=None):
        data = {}
        data["success"] = True
        return Response(data)


class Step2View(APIView):

    def get(self, request):

        tags = request.GET.get("tag")
        data = []
        error = {}
        if tags:
            try:
                tags_list = tags.split(",")
                for i in tags_list:
                    i = i.strip()
                    link = "https://hatchways.io/api/assessment/blog/posts?tag="+i
                    cached_data = cache.get(i)
                    if not cached_data:
                        result = requests.get(link).json()
                        result = result["posts"]
                        cache.set(i, result, 500)
                        data.append(result)
                    else:
                        data.append(cached_data)
                if len(data)>1:
                    for i in (range(len(data)-1)):
                        final_data = {x['id']:x for x in data[i] + data[i+1]}.values()

                else:

                    final_data = data
                final_data = list(final_data)
                return Response(final_data)
            except:
                error["error"] = "Error. Please try again"
                return Response(error)
        else:
            error["error"] = "Tags parameter is required"
            return Response(error, status = status.HTTP_400_BAD_REQUEST)

class Step3View(APIView):

    def get(self, request):
        error = {}
        posts = []
        posts_data = []
        tags = self.request.GET.get("tag")
        sortBy = self.request.GET.get("sortBy")
        direction = self.request.GET.get("direction", "")
        sortBy_choice = ["id", "reads", "likes", "popularity"]
        direction_choice = ["asc", "desc"]
        try:
            if tags:
                link = "https://hatchways.io/api/assessment/blog/posts"
                cached_data = get_cached_data(link, "step3")
                tags_list = tags.split(",")
                posts = cached_data["posts"]
                for i in posts:
                    if any(map(lambda v: v in tags_list, i["tags"])) is True:
                        posts_data.append(i)
                if sortBy:
                    if sortBy in sortBy_choice:
                        if direction not in direction_choice:
                            direction = "asc"
                            sorted_data = sorted(posts_data, key=itemgetter(sortBy))
                            return Response(sorted_data)
                        elif direction == "desc":
                            sorted_data = sorted(posts_data, key=itemgetter(sortBy), reverse=True)
                            return Response(sorted_data)
                    else:
                        error["error"] = "sortBy parameter is invalid"
                        return Response(error, status = status.HTTP_400_BAD_REQUEST)
                return Response(posts_data)
            else:
                error["error"] = "Tags parameter is required"
                return Response(error, status = status.HTTP_400_BAD_REQUEST)
        except:
            error["error"] = "Error. Please try again"
            return Response(error)

class Step4View(APIView):

    def get(self, request):
        try:
            author_link = "https://hatchways.io/api/assessment/blog/authors"
            post_link = "https://hatchways.io/api/assessment/blog/posts"

            author_data = get_cached_data(author_link, "step4_author")
            posts_data= get_cached_data(post_link, "step4_posts")

            authors = (author_data["authors"])
            posts = posts_data["posts"]

            error = {}
            main_result = {}
            posts_list = []
            author_list = []
            count_likes = 0
            count_reads = 0
            tags_list = []

            for i in authors:
                for j in posts:
                    if i["id"] == j["authorId"]:
                        posts_list.append(j)
                        tags_list.append(j["tags"])
                        count_likes = count_likes+j["likes"]
                        count_reads = count_reads+j["reads"]

                tags_list = list(itertools.chain.from_iterable(tags_list))
                tags_list = list(set(tags_list))

                i["posts"] = posts_list
                i["tags"] = tags_list
                i["totalLikeCount"] = count_likes
                i["totalReadCount"] = count_reads

                #Assigning values to author dict
                author_list.append(i)
                #Resetting variables to get new values
                posts_list = []
                count_reads = 0
                count_likes = 0
                tags_list =[]


            main_result["authors"] = author_list
            return Response(main_result)
        except:
            error["error"] = "Error. Please try again"
            return Response(error)


